﻿using System;

namespace ProyectoBD.CapaEntidad
{
    public class Alumno
    {
        public int IdAlumno { get; set; }
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public int IdSeccion { get; set; }
        public decimal Pension { get; set; }
        public DateTime Fecha { get; set; }

        public string RutaImagen { get; set; }

    }
}
