﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoBD.CapaEntidad
{
    public class Seccion
    {
        public int Id { get; set; }
        public string Texto { get; set; }
    }
}
