﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoBD.Ejemplo
{
    internal class Coche
    {
        // CAMPO (Generalmente privado para proteger la información)
        private string modelo;

        // PROPIEDAD (Acceso seguro al campo)
        public string Modelo
        {
            get { return modelo; }
            set
            {
                // Permite validar datos antes de asignarlos
                if (!string.IsNullOrEmpty(value))
                    modelo = value;
            }
        }

        // PROPIEDAD AUTO-IMPLEMENTADA (C# simplifica la creación de campos ocultos)
        public string Color { get; set; }

        // MÉTODO (Comportamiento)
        public void Arrancar()
        {
            Console.WriteLine($"El coche {Modelo} ha arrancado.");
        }

    }
}

/*
 
                 // Creación del OBJETO a partir de la CLASE
                Coche miCoche = new Coche();

                // Uso de propiedades
                miCoche.Modelo = "Toyota Corolla";
                miCoche.Color = "Rojo";

                // Uso de métodos
                miCoche.Arrancar();
 
 */
