﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoBD.Ejemplo
{
    internal class Persona
    {
        //forma automática (auto-property)
        public string Nombres { get; set; }
        public string Apellidos { get; set; }


        //Forma compacta con expresión lambda(=>) :
        private string dni;
        public string Dni { get => dni; set => dni = value; }


        //Forma completa(larga o tradicional):
        private string estadoCivil;
        public string EstadoCivil
        {
            get { return estadoCivil; }
            set { estadoCivil = value; }
        }

        private int edad;
        public int Edad
        {
            get { return edad; }
            set
            {
                if (value < 0)
                {
                    MessageBox.Show("La edad no puede ser negativa. Se asignará 0.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    edad = 0;
                }
                else
                {
                    edad = value;
                }
            }
        }

    }

    /*
    La Programación Orientada a Objetos (POO) en C# es un paradigma que organiza el código utilizando "moldes" y entidades. 
    Para entender sus elementos clave, imagina la clase como el plano de una casa y el objeto como la casa ya construida


    Clase: Es la plantilla o plano que define las características y comportamientos de lo que será el objeto. 
            Define la estructura general.

    Objeto: Es una instancia o ejemplar concreto creado a partir de una clase. Puedes tener múltiples objetos basados en un mismo plano, 
            cada uno con datos independientes.


    Campos: Son las variables declaradas directamente en la clase. 
        Almacenan el estado o los datos crudos del objeto (ej. color, tamaño) y suelen ser privados.


    Propiedades: Son mecanismos que permiten leer, escribir o validar el valor de los campos. 
        Actúan como un puente seguro para acceder a los datos internos, utilizando bloques get (obtener) y set (establecer).

    Métodos: Son las funciones o acciones que el objeto puede realizar. 
    Describen el comportamiento, como por ejemplo arrancar (en un coche) o caminar (en una persona)

 */

}
