﻿using ProyectoBD.CapaDatos;
using ProyectoBD.CapaEntidad;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace ProyectoBD
{
    public partial class frmAlumno : Form
    {
        private readonly AlumnoCD _alumnoCD = new AlumnoCD();
        private List<Alumno> _alumnos = new List<Alumno>();
        private Alumno _alumnoSeleccionado = null;

        private string RutaArchivo;
     


        public frmAlumno()
        {
            InitializeComponent();
            ConfigurarGrid();
            CargarComboBoxSecciones();

            txtCodigo.ReadOnly = true;
            dtpFechaDesde.Value = DateTime.Now.AddMonths(-1);
            dtpFechaHasta.Value = DateTime.Now;

            RutaArchivo = "C:\\";
        }

        private void frmAlumno_Load(object sender, EventArgs e)
        {
            CargarAlumnos();
        }


        private void CargarAlumnos()
        {
            try
            {
                _alumnos = _alumnoCD.Buscar() ?? new List<Alumno>();
                RefrescarGrid(_alumnos);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar alumnos:\n{ex.Message}",
                                "Error de conexión", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos()) return;

            Alumno nuevo = new Alumno
            {
                Nombres = txtNombre.Text.Trim(),
                Apellidos = txtApellidos.Text.Trim(),
                IdSeccion = (int)cboSeccion.SelectedValue,
                Pension = decimal.Parse(txtPension.Text.Trim()),
                Fecha = dtpFecha.Value.Date,
                RutaImagen = txtRutaImagen.Text.Trim()
            };

            try
            {
                bool ok = _alumnoCD.Agregar(nuevo);

                if (ok)
                {
                    CargarAlumnos();
                    LimpiarCampos();
                    MessageBox.Show("Alumno agregado correctamente.", "Éxito",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("No se pudo agregar el alumno.", "Aviso",
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al agregar:\n{ex.Message}",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (_alumnoSeleccionado == null)
            {
                MessageBox.Show("Seleccione un alumno del listado para actualizar.",
                                "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!ValidarCampos()) return;

            Alumno modificado = new Alumno
            {
                IdAlumno = _alumnoSeleccionado.IdAlumno, // ID que viene de la BD
                Nombres = txtNombre.Text.Trim(),
                Apellidos = txtApellidos.Text.Trim(),
                IdSeccion = (int)cboSeccion.SelectedValue,
                Pension = decimal.Parse(txtPension.Text.Trim()),
                Fecha = dtpFecha.Value.Date,
                RutaImagen = txtRutaImagen.Text.Trim()
            };

            try
            {
                bool ok = _alumnoCD.Modificar(modificado);

                if (ok)
                {
                    CargarAlumnos();
                    LimpiarCampos();
                    _alumnoSeleccionado = null;
                    MessageBox.Show("Alumno actualizado correctamente.", "Éxito",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("No se pudo actualizar el alumno.", "Aviso",
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al actualizar:\n{ex.Message}",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (_alumnoSeleccionado == null)
            {
                MessageBox.Show("Seleccione un alumno del listado para eliminar.",
                                "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult confirm = MessageBox.Show(
                $"¿Desea eliminar al alumno '{_alumnoSeleccionado.Nombres} {_alumnoSeleccionado.Apellidos}'?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirm == DialogResult.Yes)
            {
                try
                {
                    bool ok = _alumnoCD.Eliminar(_alumnoSeleccionado.IdAlumno);

                    if (ok)
                    {
                        CargarAlumnos();
                        LimpiarCampos();
                        _alumnoSeleccionado = null;
                        MessageBox.Show("Alumno eliminado correctamente.", "Éxito",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("No se pudo eliminar el alumno.", "Aviso",
                                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al eliminar:\n{ex.Message}",
                                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnFind_Click(object sender, EventArgs e)
        {

            string nombres = string.IsNullOrWhiteSpace(txtNombreBusqueda.Text)
                                ? null : txtNombreBusqueda.Text.Trim();

            string apellidos = string.IsNullOrWhiteSpace(txtApellidoBusqueda.Text)
                                ? null : txtApellidoBusqueda.Text.Trim();

            int seccion = Convert.ToInt32(cboSeccionBusqueda.SelectedValue);
            int? idSeccion = seccion > 0 ? (int?)seccion : null;


            bool filtrarPension = decimal.TryParse(txtPensionBusqueda.Text, out decimal pension);
            decimal? pensionFiltro = filtrarPension ? (decimal?)pension : null;


            bool filtrarFecha = cbxRango.Checked;
            DateTime? fechaDesde = filtrarFecha ? dtpFechaDesde.Value.Date : (DateTime?)null;
            DateTime? fechaHasta = filtrarFecha ? dtpFechaHasta.Value.Date : (DateTime?)null;

            // Validar rango solo si el checkbox está activo
            if (filtrarFecha && fechaDesde > fechaHasta)
            {
                MessageBox.Show("La fecha 'Desde' no puede ser mayor que la fecha 'Hasta'.",
                                "Rango inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                List<Alumno> resultado = _alumnoCD.Buscar(
                    nombres: nombres,
                    apellidos: apellidos,
                    idSeccion: idSeccion,
                    pension: pensionFiltro,
                    fechaDesde: fechaDesde,
                    fechaHasta: fechaHasta
                );

                RefrescarGrid(resultado ?? new List<Alumno>());

                if (resultado == null || resultado.Count == 0)
                    MessageBox.Show("No se encontraron alumnos con los criterios indicados.",
                                    "Sin resultados", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al buscar:\n{ex.Message}",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLimpiarBusqueda_Click(object sender, EventArgs e)
        {
            txtNombreBusqueda.Clear();
            txtApellidoBusqueda.Clear();
            txtPensionBusqueda.Clear();
            cboSeccionBusqueda.SelectedIndex = 0;
            dtpFechaDesde.Value = DateTime.Now.AddMonths(-1);
            dtpFechaHasta.Value = DateTime.Now;
            CargarAlumnos();
        }
        private void dgvAlumno_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (dgvAlumno.SelectedRows.Count > 0)
                {
                    DataGridViewRow fila = dgvAlumno.SelectedRows[0];

                    if (int.TryParse(fila.Cells["IdAlumno"].Value?.ToString(), out int id))
                    {
                        // Buscar en _alumnos (no va a la BD en cada clic)
                        _alumnoSeleccionado = _alumnos.FirstOrDefault(a => a.IdAlumno == id);
                    }

                    if (_alumnoSeleccionado == null) return;

                    txtCodigo.Text = _alumnoSeleccionado.IdAlumno.ToString();
                    txtNombre.Text = _alumnoSeleccionado.Nombres;
                    txtApellidos.Text = _alumnoSeleccionado.Apellidos;
                    txtPension.Text = _alumnoSeleccionado.Pension.ToString();
                    dtpFecha.Value = _alumnoSeleccionado.Fecha;
                    cboSeccion.SelectedValue = _alumnoSeleccionado.IdSeccion;
                    txtRutaImagen.Text = _alumnoSeleccionado.RutaImagen;

                    txtRutaImagen.Text = _alumnoSeleccionado.RutaImagen; if (!string.IsNullOrEmpty(txtRutaImagen.Text))
                    {
                        try
                        {
                            string rutaImagenCompleta = Path.Combine(RutaArchivo, txtRutaImagen.Text);
                            pbImagen.LoadAsync(rutaImagenCompleta);

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: No se puede cargar la imagen . " + ex.Message);
                        }

                    }

                    else
                    {
                        LiberarImagenPicture();

                    }
                
                }

                        }
                
            
            catch (Exception ex)
            {
                Console.WriteLine($"Error en selección: {ex.Message}");
            }
        }



        private void ConfigurarGrid()
        {
            dgvAlumno.ReadOnly = true;
            dgvAlumno.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvAlumno.MultiSelect = false;
            dgvAlumno.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void RefrescarGrid(List<Alumno> lista)
        {
            dgvAlumno.DataSource = null;
            dgvAlumno.DataSource = lista;
        }

        private void LimpiarCampos()
        {
            txtCodigo.Clear();
            txtNombre.Clear();
            txtApellidos.Clear();
            txtPension.Clear();
            cboSeccion.SelectedIndex = 0;
            dtpFecha.Value = DateTime.Now;
            _alumnoSeleccionado = null;

            txtNombre.Focus();
        }

        private void CargarComboBoxSecciones()
        {
            List<Seccion> secciones = new List<Seccion>
            {
                new Seccion { Id = 0, Texto = "-- Seleccione --" },
                new Seccion { Id = 1, Texto = "Sección A" },
                new Seccion { Id = 2, Texto = "Sección B" },
                new Seccion { Id = 3, Texto = "Sección C" },
                new Seccion { Id = 4, Texto = "Sección D" }
            };


            cboSeccion.DataSource = secciones;
            cboSeccion.DisplayMember = "Texto";
            cboSeccion.ValueMember = "Id";
            cboSeccion.SelectedIndex = 0;


            cboSeccionBusqueda.DataSource = new List<Seccion>(secciones);
            cboSeccionBusqueda.DisplayMember = "Texto";
            cboSeccionBusqueda.ValueMember = "Id";
            cboSeccionBusqueda.SelectedIndex = 0;
        }



        private bool ValidarCampos()
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("El campo Nombres es obligatorio.", "Validación",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNombre.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtApellidos.Text))
            {
                MessageBox.Show("El campo Apellidos es obligatorio.", "Validación",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtApellidos.Focus();
                return false;
            }

            if (cboSeccion.SelectedValue == null || (int)cboSeccion.SelectedValue == 0)
            {
                MessageBox.Show("Debe seleccionar una Sección.", "Validación",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboSeccion.Focus();
                return false;
            }

            if (!decimal.TryParse(txtPension.Text.Trim(), out decimal pension) || pension <= 0)
            {
                MessageBox.Show("Ingrese un valor numérico válido para la Pensión.", "Validación",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPension.Focus();
                return false;
            }

            return true;
        }

        private void cbxRango_CheckedChanged(object sender, EventArgs e)
        {
            dtpFechaDesde.Enabled = cbxRango.Checked;
            dtpFechaHasta.Enabled = cbxRango.Checked;
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        private void btnSeleccionarImagen_Click(object sender, EventArgs e)
        {
              using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Title = "Seleccionar imagen";
                ofd.Filter = "Imagenes|*.jpg;*.jpeg;*.png;*.bmp;*.jfif";
                ofd.Multiselect = false;

                if (ofd.ShowDialog() != DialogResult.OK)
                    return;

                try { string rutaGuardada = GuardarImagen(ofd.FileName);
                    
                    txtRutaImagen.Text = rutaGuardada;
                    
                    LiberarImagenPicture();
                    
                    pbImagen.Image = CargarImagenSinBloquear(ofd.FileName); 
                    pbImagen.SizeMode = PictureBoxSizeMode.StretchImage; 
                }
             
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar la imagen: " + ex.Message);

            }
         
            }
        }

        private string GuardarImagen(string rutaOrigen)
        {
            string carpetaDestino = Path.Combine(RutaArchivo, "Fotos");
            if (!Directory.Exists(carpetaDestino))
            {
                Directory.CreateDirectory(carpetaDestino);
            }
            string extension = Path.GetExtension(rutaOrigen);
            string nombreImagen = Guid.NewGuid().ToString("N") + extension;
            string rutaDestino = Path.Combine(carpetaDestino, nombreImagen);

            File.Copy(rutaOrigen, rutaDestino, true);

            return Path.Combine("Fotos", nombreImagen);

        }

        private void LiberarImagenPicture()
        {
            if (pbImagen.Image != null)
            {
                pbImagen.Image.Dispose();
                pbImagen.Image =  null;
            }

        }

        private Image CargarImagenSinBloquear(string ruta)
        {
            byte[] bytesImagen = File.ReadAllBytes(ruta);

            using (MemoryStream ms = new MemoryStream(bytesImagen))
            using (Image imagenTemporal = Image.FromStream(ms))
            {
                return new Bitmap(imagenTemporal);
            }
        }




        /*
            operador de fusión nula ??
            --------------------------
            Sintaxis
            resultado = variable ?? valor_por_defecto;.

            El operador ?? significa: "si lo de la izquierda es null, usa lo de la derecha"

            string nombre = null;
            // Si nombre es nulo, se asigna "Invitado"
            string nombreFinal = nombre ?? "Invitado"; 
            Console.WriteLine(nombreFinal); // Salida: Invitado


            operador ternario 
            ----------------
            Sintaxis:
            condición ? expresión_si_verdadero : expresión_si_falso;

            Evalúa una expresión y devuelve un valor si es verdadera y otro si es falsa.
            es una forma concisa de escribir una sentencia if-else en una sola línea 

            string resultado = (edad >= 18) ? "Mayor de edad" : "Menor de edad";

         */
    }

}

