﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProyectoBD.CapaEntidad;
using System.Data.SqlClient;
using System.Configuration;

namespace ProyectoBD.CapaDatos
{
    public class AlumnoCD
    {
        private string ConnectionString
        {
            get
            {
                var config = ConfigurationManager.ConnectionStrings["MiConexion"];
                if (config == null)
                {
                    throw new InvalidOperationException("No se encontró la cadena de conexión 'MiConexion' en el archivo de configuración.");
                }
                return config.ConnectionString;
            }
        }

        public List<Alumno> Buscar(string nombres = null, string apellidos = null,
                            int? idSeccion = null, decimal? pension = null,
                            DateTime? fechaDesde = null, DateTime? fechaHasta = null)
        {
            List<Alumno> lstObj = null;

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (var cmd = new SqlCommand("[dbo].[USP_BUSCAR_ALUMNO]", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Pasar NULL cuando no se quiere filtrar
                    cmd.Parameters.Add("@Nombres", SqlDbType.VarChar, 100).Value = (object)nombres ?? DBNull.Value;
                    cmd.Parameters.Add("@Apellidos", SqlDbType.VarChar, 100).Value = (object)apellidos ?? DBNull.Value;
                    cmd.Parameters.Add("@IdSeccion", SqlDbType.Int).Value = (object)idSeccion ?? DBNull.Value;
                    cmd.Parameters.Add("@Pension", SqlDbType.Decimal).Value = (object)pension ?? DBNull.Value;
                    cmd.Parameters.Add("@FechaDesde", SqlDbType.DateTime).Value = (object)fechaDesde ?? DBNull.Value;
                    cmd.Parameters.Add("@FechaHasta", SqlDbType.DateTime).Value = (object)fechaHasta ?? DBNull.Value;

                    using (var drd = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (drd != null)
                        {
                            lstObj = new List<Alumno>();
                            Alumno obj;

                            if (drd.HasRows)
                            {
                                int IdAlumno = drd.GetOrdinal("IdAlumno");
                                int Nombres = drd.GetOrdinal("Nombres");
                                int Apellidos = drd.GetOrdinal("Apellidos");
                                int IdSeccion = drd.GetOrdinal("IdSeccion");
                                int Pension = drd.GetOrdinal("Pension");
                                int Fecha = drd.GetOrdinal("Fecha");
                                int RutaImagen = drd.GetOrdinal("RutaImagen");

                                while (drd.Read())
                                {
                                    obj = new Alumno();

                                    if (!drd.IsDBNull(IdAlumno)) obj.IdAlumno = drd.GetInt32(IdAlumno);
                                    if (!drd.IsDBNull(Nombres)) obj.Nombres = drd.GetString(Nombres);
                                    if (!drd.IsDBNull(Apellidos)) obj.Apellidos = drd.GetString(Apellidos);
                                    if (!drd.IsDBNull(IdSeccion)) obj.IdSeccion = drd.GetInt32(IdSeccion);
                                    if (!drd.IsDBNull(Pension)) obj.Pension = drd.GetDecimal(Pension);
                                    if (!drd.IsDBNull(Fecha)) obj.Fecha = drd.GetDateTime(Fecha);
                                    if (!drd.IsDBNull(RutaImagen)) obj.RutaImagen = drd.GetString(RutaImagen);
                                        

                                    lstObj.Add(obj);
                                }
                            }
                        }
                    }
                }
            }
            return lstObj;
        }

   
        public Alumno ConsultarPorId(int id)
        {
            Alumno obj = null;
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (var cmd = new SqlCommand("[dbo].[USP_CONSULTAR_ALUMNO_POR_ID]", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@IdAlumno", SqlDbType.Int).Value = id;
                    using (var drd = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (drd != null && drd.HasRows && drd.Read())
                        {
                            obj = new Alumno();
                            int IdAlumno = drd.GetOrdinal("IdAlumno");
                            int Nombres = drd.GetOrdinal("Nombres");
                            int Apellidos = drd.GetOrdinal("Apellidos");
                            int IdSeccion = drd.GetOrdinal("IdSeccion");
                            int Pension = drd.GetOrdinal("Pension");
                            int Fecha = drd.GetOrdinal("Fecha");
                            int RutaImagen = drd.GetOrdinal("RutaImagen");

                            if (!drd.IsDBNull(IdAlumno)) obj.IdAlumno = drd.GetInt32(IdAlumno);
                            if (!drd.IsDBNull(Nombres)) obj.Nombres = drd.GetString(Nombres);
                            if (!drd.IsDBNull(Apellidos)) obj.Apellidos = drd.GetString(Apellidos);
                            if (!drd.IsDBNull(IdSeccion)) obj.IdSeccion = drd.GetInt32(IdSeccion);
                            if (!drd.IsDBNull(Pension)) obj.Pension = drd.GetDecimal(Pension);
                            if (!drd.IsDBNull(Fecha)) obj.Fecha = drd.GetDateTime(Fecha);
                            if (!drd.IsDBNull(RutaImagen)) obj.RutaImagen = drd.GetString(RutaImagen);
                        }
                    }
                }
            }
            return obj;
        }

        public bool Agregar(Alumno alumno)
        {
            bool resultado = false;
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (var cmd = new SqlCommand("[dbo].[USP_AGREGAR_ALUMNO]", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@Nombres", SqlDbType.VarChar, 100).Value = alumno.Nombres ?? (object)DBNull.Value;
                    cmd.Parameters.Add("@Apellidos", SqlDbType.VarChar, 100).Value = alumno.Apellidos ?? (object)DBNull.Value;
                    cmd.Parameters.Add("@IdSeccion", SqlDbType.Int).Value = alumno.IdSeccion;
                    cmd.Parameters.Add("@Pension", SqlDbType.Decimal).Value = alumno.Pension;
                    cmd.Parameters.Add("@Fecha", SqlDbType.DateTime).Value = alumno.Fecha;
                    cmd.Parameters.Add("@RutaImagen", SqlDbType.VarChar,1000).Value = alumno.RutaImagen ?? (object)DBNull.Value;


                    int filasAfectadas = cmd.ExecuteNonQuery();
                    resultado = filasAfectadas > 0;
                }
            }
            return resultado;
        }

        public bool Modificar(Alumno alumno)
        {
            bool resultado = false;
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (var cmd = new SqlCommand("[dbo].[USP_MODIFICAR_ALUMNO]", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@IdAlumno", SqlDbType.Int).Value = alumno.IdAlumno;
                    cmd.Parameters.Add("@Nombres", SqlDbType.VarChar, 100).Value = alumno.Nombres ?? (object)DBNull.Value;
                    cmd.Parameters.Add("@Apellidos", SqlDbType.VarChar, 100).Value = alumno.Apellidos ?? (object)DBNull.Value;
                    cmd.Parameters.Add("@IdSeccion", SqlDbType.Int).Value = alumno.IdSeccion;
                    cmd.Parameters.Add("@Pension", SqlDbType.Decimal).Value = alumno.Pension;
                    cmd.Parameters.Add("@Fecha", SqlDbType.DateTime).Value = alumno.Fecha;
                    cmd.Parameters.Add("@RutaImagen", SqlDbType.VarChar,1000).Value = alumno.RutaImagen ?? (object)DBNull.Value;

                    int filasAfectadas = cmd.ExecuteNonQuery();
                    resultado = filasAfectadas > 0;
                }
            }
            return resultado;
        }

        public bool Eliminar(int id)
        {
            bool resultado = false;
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (var cmd = new SqlCommand("[dbo].[USP_ELIMINAR_ALUMNO]", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@IdAlumno", SqlDbType.Int).Value = id;

                    int filasAfectadas = cmd.ExecuteNonQuery();
                    resultado = filasAfectadas > 0;
                }
            }
            return resultado;
        }
    }
}
